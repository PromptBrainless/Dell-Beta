import { useEffect, useRef, useState } from "react";
import { AKTIONEN } from "@/game/w100/aktionen";
import { bonus, CHARAKTERE, charakter, type CharakterId } from "@/game/w100/charaktere";
import { BAU, BREITE, bereich, inSchablone, istBau, index, type Feld } from "@/game/w100/karte";
import { abwehrWaehlen, ankuendigen, bedroht, bewegen, bot, formName, kann, laufFelder, makro, neuerKampf, passen, type Kampf, type Seite } from "@/game/w100/kampf";
import { foundryPaket, roll20Paket } from "@/game/w100/export";
import { ZONE_NAME, type Zone } from "@/game/w100/regeln";
import { SpielerBlick } from "./spieler-blick";

const ZONEN: Zone[] = ["kopf", "arm-links", "arm-rechts", "koerper", "bein-links", "bein-rechts"];

export function BreachApp({ onArchiv }: { onArchiv: () => void }) {
  const [kampf, setKampf] = useState<Kampf | null>(null);
  const [a, setA] = useState<CharakterId>("brecher");
  const [b, setB] = useState<CharakterId>("jaeger");
  const [modus, setModus] = useState<"bot" | "gegen">("bot");
  const [wahl, setWahl] = useState<"bewegen" | "schlagen" | null>(null);
  const [zone, setZone] = useState<Zone>("koerper");
  const [blatt, setBlatt] = useState(false);

  useEffect(() => {
    if (!kampf || kampf.vorbei || modus !== "bot" || kampf.amZug !== "B") return;
    const timer = window.setTimeout(() => setKampf(bot(kampf)), 1500);
    return () => window.clearTimeout(timer);
  }, [kampf, modus]);

  if (!kampf) {
    return (
      <main className="mx-auto flex min-h-dvh max-w-3xl flex-col gap-6 px-4 py-8">
        <p className="text-xs uppercase tracking-wide text-muted">Neues Kampfsystem</p>
        <h1 className="display text-4xl">Gitter und W100</h1>
        <p className="text-sm text-muted">
          64 mal 64 Felder. Jede Waffe hat ihren eigenen Radius. Wer hineinlauft, wird getroffen.
        </p>
        <div className="grid gap-3 sm:grid-cols-2">
          <Wahl label="Du" value={a} onChange={setA} />
          <Wahl label="Gegenüber" value={b} onChange={setB} />
        </div>
        <div className="flex gap-2">
          <button type="button" className={`btn ${modus === "bot" ? "btn-on" : ""}`} onClick={() => setModus("bot")}>
            Gegen den Bot
          </button>
          <button type="button" className={`btn ${modus === "gegen" ? "btn-on" : ""}`} onClick={() => setModus("gegen")}>
            Zu zweit
          </button>
        </div>
        <button type="button" className="btn btn-primary" onClick={() => setKampf(neuerKampf(a, b))}>
          Kampf beginnen
        </button>
        <div className="flex gap-2">
          <button type="button" className="btn" onClick={() => datei("echo-bruch-foundry.json", foundryPaket([]))}>
            Foundry
          </button>
          <button type="button" className="btn" onClick={() => datei("echo-bruch-roll20.json", roll20Paket())}>
            Roll20
          </button>
        </div>
        <button type="button" className="btn" onClick={onArchiv}>
          Altes System
        </button>
      </main>
    );
  }

  const seite = kampf.amZug;
  const ich = kampf.kaempfer[seite];
  const duBist = modus === "bot" && seite === "B";
  const laufen = wahl === "bewegen" ? laufFelder(kampf, seite) : [];
  const c = charakter(ich.id);

  function waehleFeld(feld: Feld) {
    if (duBist || kampf!.vorbei) return;
    if (wahl === "bewegen") {
      setKampf(bewegen(kampf!, feld));
      setWahl(null);
    }
  }

  const auge: Seite = modus === "bot" ? "A" : seite;
  const gegnerId = kampf.kaempfer[auge === "A" ? "B" : "A"].id;

  return (
    <main className="mx-auto flex h-dvh max-w-6xl flex-col gap-2 overflow-hidden px-2 py-2">
      <header className="flex shrink-0 items-center justify-between gap-2">
        <div>
          <p className="text-[10px] uppercase tracking-wide text-muted">Am Zug</p>
          <h1 className="display text-xl sm:text-3xl">{ich.name}</h1>
        </div>
        <div className="flex flex-wrap justify-end gap-1">
          <button type="button" className="btn px-2 py-1 text-xs" onClick={() => setBlatt((an) => !an)}>
            Blatt
          </button>
          <button type="button" className="btn px-2 py-1 text-xs" onClick={() => setKampf(null)}>
            Neu
          </button>
          <button
            type="button"
            className="btn px-2 py-1 text-xs"
            onClick={() =>
              datei(
                "echo-bruch-foundry.json",
                foundryPaket([kampf.kaempfer.A, kampf.kaempfer.B].map((wer) => ({ ...charakter(wer.id), feld: wer.feld }))),
              )
            }
          >
            Foundry
          </button>
          <button type="button" className="btn px-2 py-1 text-xs" onClick={() => datei("echo-bruch-roll20.json", roll20Paket())}>
            Roll20
          </button>
          <button type="button" className="btn px-2 py-1 text-xs" onClick={onArchiv}>
            Archiv
          </button>
        </div>
      </header>
      <div className="shrink-0 overflow-hidden max-lg:max-h-24 lg:max-h-40">
        <SpielerBlick blick={kampf.blick} gegner={gegnerId} />
      </div>
      <div className="grid min-h-0 flex-1 gap-2 lg:grid-cols-[minmax(0,1fr)_17rem]">
        <div className="flex min-h-0 flex-col">
          <Gitter kampf={kampf} seite={seite} laufen={laufen} onFeld={waehleFeld} />
          <p className="mt-1 shrink-0 text-[11px] text-muted">
            {bedroht(kampf, seite)
              ? "Du stehst im Radius. Ausweichen oder Parieren gilt für den nächsten Schlag."
              : "Der Ring ist die Schablone. Farbe nur, wo kein Strahl die Mauer schneidet. Die Kette geht über den Bau."}
          </p>
        </div>
        <aside className="flex max-h-36 shrink-0 flex-col gap-1 overflow-auto lg:max-h-none">
          <Karte seite="A" kampf={kampf} />
          <Karte seite="B" kampf={kampf} />
          <p className="text-[11px] text-muted">Aktionen: {kampf.punkte}. {c.zeile}</p>
          {c.ortwahl && (
            <label className="text-[11px] text-muted">
              Zone, wenn der Schlag um 2 Grade gewinnt
              <select className="btn mt-1 w-full py-1 text-xs" value={zone} onChange={(event) => setZone(event.target.value as Zone)}>
                {ZONEN.map((item) => (
                  <option key={item} value={item}>
                    {ZONE_NAME[item]}
                  </option>
                ))}
              </select>
            </label>
          )}
          <div className="grid grid-cols-2 gap-1">
            {AKTIONEN.map((aktion) => (
              <button
                key={aktion.id}
                type="button"
                disabled={duBist || !kann(kampf, aktion.id)}
                className={`btn h-auto flex-col items-start px-2 py-1 text-left text-xs ${wahl === aktion.id ? "btn-on" : ""}`}
                onClick={() => {
                  if (aktion.id === "bewegen") setWahl(wahl === "bewegen" ? null : "bewegen");
                  if (aktion.id === "schlagen") {
                    setKampf(ankuendigen(kampf, c.ortwahl ? zone : null));
                    setWahl(null);
                  }
                  if (aktion.id === "parieren" || aktion.id === "ausweichen") setKampf(abwehrWaehlen(kampf, aktion.id));
                  if (aktion.id === "passen") setKampf(passen(kampf));
                }}
              >
                <span>{aktion.name}</span>
                <span className="text-[10px] text-faint">{aktion.text}</span>
              </button>
            ))}
          </div>
          <div className="grid grid-cols-3 gap-1">
            {(
              [
                ["hinein", "Hinein"],
                ["schlag", "Schlag"],
                ["deckung", "Deckung"],
              ] as const
            ).map(([art, name]) => (
              <button
                key={art}
                type="button"
                disabled={duBist || kampf.vorbei}
                className="btn px-2 py-1 text-xs"
                onClick={() => {
                  setKampf(makro(kampf, art, c.ortwahl ? zone : null));
                  setWahl(null);
                }}
              >
                {name}
              </button>
            ))}
          </div>
          {blatt && <Blatt seite={auge} kampf={kampf} />}
          {kampf.vorbei && <p className="display text-xl">{kampf.sieger ? `${kampf.kaempfer[kampf.sieger].name} steht.` : "Unentschieden"}</p>}
        </aside>
      </div>
      <section className="panel max-h-14 shrink-0 overflow-auto px-2 py-1">
        <ol className="flex flex-col gap-0.5 text-[11px] text-muted">
          {kampf.log.slice(0, 4).map((zeile, i) => (
            <li key={`${i}-${zeile}`}>{zeile}</li>
          ))}
        </ol>
      </section>
    </main>
  );
}

function datei(name: string, inhalt: unknown) {
  const url = URL.createObjectURL(new Blob([JSON.stringify(inhalt, null, 2)], { type: "application/json" }));
  const link = document.createElement("a");
  link.href = url;
  link.download = name;
  link.click();
  URL.revokeObjectURL(url);
}

function Blatt({ seite, kampf }: { seite: Seite; kampf: Kampf }) {
  const k = kampf.kaempfer[seite];
  const c = charakter(k.id);
  const zonen = Object.entries(c.ruestung);
  return (
    <article className="panel px-2 py-1 text-[10px] text-muted">
      <p className="display text-sm text-white">{k.name}</p>
      <p>
        WS {c.ws} · BS {c.bs} · S {c.staerke} · Z {c.widerstand} · Wille {c.wille} · Ausweichen {c.ausweichen}
      </p>
      <p>
        SB {bonus(c.staerke)} · ZB {bonus(c.widerstand)} · Wunden {k.wunden}/{k.wundenMax} · Vorteil {k.vorteil}
      </p>
      <p>
        {formName(c.form)} {c.mindest}–{c.reichweite} · Schaden {c.schaden} · Länge {c.laenge} · {c.effekt}
      </p>
      <p>{zonen.map(([zone, wert]) => `${ZONE_NAME[zone as Zone]} ${wert}`).join(" · ")}</p>
    </article>
  );
}

function Gitter({
  kampf,
  seite,
  laufen,
  onFeld,
}: {
  kampf: Kampf;
  seite: Seite;
  laufen: Feld[];
  onFeld: (feld: Feld) => void;
}) {
  const flaeche = useRef<HTMLCanvasElement>(null);
  const rahmen = useRef<HTMLDivElement>(null);
  const gesehen = useRef(false);
  const zelle = 22;
  const kante = BREITE * zelle;

  useEffect(() => {
    if (!kampf) return;
    if (gesehen.current) return;
    gesehen.current = true;
    const box = rahmen.current;
    if (!box) return;
    const ich = kampf.kaempfer[kampf.amZug];
    box.scrollLeft = Math.max(0, ich.feld.x * zelle - box.clientWidth / 2);
    box.scrollTop = Math.max(0, ich.feld.y * zelle - box.clientHeight / 2);
  }, [kampf]);

  useEffect(() => {
    const canvas = flaeche.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const dpr = Math.min(3, Math.max(2, window.devicePixelRatio || 2));
    canvas.width = kante * dpr;
    canvas.height = kante * dpr;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.fillStyle = "#151b19";
    ctx.fillRect(0, 0, kante, kante);

    const ich = kampf.kaempfer[seite];
    const gegner = kampf.kaempfer[seite === "A" ? "B" : "A"];
    const ic = charakter(ich.id);
    const gc = charakter(gegner.id);
    const schritte = new Set(laufen.map(index));

    for (let y = 0; y < BREITE; y += 1) {
      for (let x = 0; x < BREITE; x += 1) {
        const feld = { x, y };
        const id = y * BREITE + x;
        const px = x * zelle;
        const py = y * zelle;
        const schatten =
          (inSchablone(gegner.feld, feld, gc.reichweite, gc.mindest) || inSchablone(ich.feld, feld, ic.reichweite, ic.mindest)) &&
          !istBau(feld);
        const fremd = bereich(gc.form, gegner.feld, feld, gc.reichweite, gc.mindest);
        const eigen = bereich(ic.form, ich.feld, feld, ic.reichweite, ic.mindest);
        ctx.fillStyle = schatten && !fremd && !eigen ? "#101411" : "#1a201e";
        ctx.fillRect(px, py, zelle - 1, zelle - 1);
        if (fremd) {
          ctx.fillStyle = "rgba(225,106,78,0.42)";
          ctx.fillRect(px, py, zelle - 1, zelle - 1);
        }
        if (eigen) {
          ctx.fillStyle = "rgba(241,238,229,0.28)";
          ctx.fillRect(px, py, zelle - 1, zelle - 1);
        }
        if (schritte.has(id)) {
          ctx.fillStyle = "rgba(232,201,141,0.55)";
          ctx.fillRect(px, py, zelle - 1, zelle - 1);
        }
      }
    }

    ctx.fillStyle = "#252d2a";
    for (const feld of BAU) ctx.fillRect(feld.x * zelle, feld.y * zelle, zelle - 1, zelle - 1);
    ring(ctx, gegner.feld, gc.reichweite, zelle, "rgba(225,106,78,0.95)");
    if (gc.mindest > 1) ring(ctx, gegner.feld, gc.mindest, zelle, "rgba(225,106,78,0.95)");
    ring(ctx, ich.feld, ic.reichweite, zelle, "rgba(241,238,229,0.9)");
    if (ic.mindest > 1) ring(ctx, ich.feld, ic.mindest, zelle, "rgba(241,238,229,0.9)");

    ctx.font = "700 13px Fraunces, Palatino, serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    for (const wer of [kampf.kaempfer.A, kampf.kaempfer.B]) {
      const px = wer.feld.x * zelle + (zelle - 1) / 2;
      const py = wer.feld.y * zelle + (zelle - 1) / 2;
      ctx.fillStyle = wer.seite === "A" ? "#f1eee5" : "#e16a4e";
      ctx.beginPath();
      ctx.arc(px, py, 8, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#151a18";
      ctx.fillText(wer.seite, px, py + 0.5);
    }
  }, [kampf, seite, laufen, kante]);

  return (
    <div ref={rahmen} className="h-full min-h-0 overflow-auto rounded-md border border-line">
      <canvas
        ref={flaeche}
        style={{ width: kante, height: kante }}
        onClick={(event) => {
          const rect = event.currentTarget.getBoundingClientRect();
          const x = Math.floor(((event.clientX - rect.left) / rect.width) * BREITE);
          const y = Math.floor(((event.clientY - rect.top) / rect.height) * BREITE);
          if (x < 0 || y < 0 || x >= BREITE || y >= BREITE) return;
          onFeld({ x, y });
        }}
      />
    </div>
  );
}

function ring(ctx: CanvasRenderingContext2D, feld: Feld, radius: number, zelle: number, farbe: string) {
  ctx.beginPath();
  ctx.arc(feld.x * zelle + (zelle - 1) / 2, feld.y * zelle + (zelle - 1) / 2, radius * zelle, 0, Math.PI * 2);
  ctx.strokeStyle = farbe;
  ctx.lineWidth = 2;
  ctx.stroke();
}

function Wahl({ label, value, onChange }: { label: string; value: CharakterId; onChange: (id: CharakterId) => void }) {
  return (
    <label className="text-sm">
      {label}
      <select className="btn mt-1 w-full" value={value} onChange={(event) => onChange(event.target.value as CharakterId)}>
        {CHARAKTERE.map((item) => (
          <option key={item.id} value={item.id}>
            {item.name} · {item.zeile}
          </option>
        ))}
      </select>
    </label>
  );
}

function Karte({ seite, kampf }: { seite: Seite; kampf: Kampf }) {
  const k = kampf.kaempfer[seite];
  const c = charakter(k.id);
  return (
    <article className={`panel px-2 py-1 ${kampf.amZug === seite ? "ring-1 ring-white/40" : ""}`}>
      <div className="flex items-baseline justify-between">
        <h2 className="display text-sm">{k.name}</h2>
        <p className="text-[10px] text-muted">{seite}</p>
      </div>
      <p className="text-[10px] tabular-nums text-muted">
        {k.wunden}/{k.wundenMax} · Vorteil {k.vorteil} · Radius {c.mindest}–{c.reichweite} · {formName(c.form)}
      </p>
      <p className="text-xs text-faint">
        {k.abwehr !== "keine" ? k.abwehr : "keine Abwehr"}
        {k.liegt ? " · liegt" : ""}
        {k.blutung ? " · blutet" : ""}
      </p>
    </article>
  );
}
