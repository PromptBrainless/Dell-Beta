/* Zusatzmodule: Würfelanzeige, Trefferzonen-Figur mit Zonenwahl, Krit-/Patzertafeln.
   Hört auf die Events 'blick' und 'fightStart' der bridge.js. */
import * as W from './w100.js';
const ZN = W.ZONE_NAME, ZONES = Object.keys(ZN), REV = Object.fromEntries(ZONES.map(z => [ZN[z], z]));
const ART = { treffer: 'Treffer', daneben: 'Vorbei', pariert: 'Pariert', ausgewichen: 'Ausgewichen', gebrochen: 'Gebrochen', patzer: 'Patzer' };
window.hudZone = null;                                   // gewählte Trefferzone (nur Figuren mit ortwahl)
let zoneWahl = false, last = null, timer = null;

const SHAPES = {                                         // Ansicht von vorn: links der Figur = rechts im Bild
  kopf: '<circle cx="60" cy="22" r="16"/>', koerper: '<rect x="40" y="42" width="40" height="60" rx="8"/>',
  'arm-links': '<rect x="84" y="44" width="14" height="56" rx="6"/>', 'arm-rechts': '<rect x="22" y="44" width="14" height="56" rx="6"/>',
  'bein-links': '<rect x="62" y="106" width="16" height="82" rx="6"/>', 'bein-rechts': '<rect x="42" y="106" width="16" height="82" rx="6"/>' };
const LABEL = { kopf: [60, 26], koerper: [60, 76], 'arm-links': [91, 76], 'arm-rechts': [29, 76], 'bein-links': [70, 150], 'bein-rechts': [50, 150] };
const panel = el('div', 'panel zone-panel', `
  <div class="zp-head"><b>Wurf und Treffer</b><button id="tafelBtn" title="Taste T">Tafeln</button></div>
  <div class="zp-dice"><div class="d-main">–</div><div class="d-sub">Noch kein Wurf</div></div>
  <svg class="zp-body" viewBox="0 0 120 200">${ZONES.map(z => `<g data-z="${z}"><g class="zone">${SHAPES[z]}</g><text x="${LABEL[z][0]}" y="${LABEL[z][1]}"></text></g>`).join('')}</svg>
  <div class="zp-info">Zahl = Rüstung der getroffenen Figur</div>`);
panel.querySelectorAll('.zone').forEach(g => g.setAttribute('class', 'zone'));
document.body.appendChild(panel);
const zoneG = z => $(`g[data-z="${z}"]`, panel);

/* Zonenwahl: nur wenn die eigene Figur ortwahl hat */
panel.querySelectorAll('g[data-z]').forEach(g => g.addEventListener('click', () => {
  if (!zoneWahl) return;
  const z = g.dataset.z; window.hudZone = window.hudZone === z ? null : z;
  panel.querySelectorAll('g[data-z]').forEach(x => x.classList.toggle('sel', x.dataset.z === window.hudZone));
  $('.zp-info', panel).textContent = window.hudZone ? `Zielzone: ${ZN[z]}` : 'Zielzone: zufällig';
}));
on('fightStart', d => {
  zoneWahl = !!d.zoneWahl; window.hudZone = null; last = null;
  panel.querySelectorAll('g[data-z]').forEach(g => { g.classList.remove('sel', 'hit'); g.classList.toggle('pick', zoneWahl); $('text', g).textContent = ''; });
  $('.d-main', panel).textContent = '–'; $('.d-sub', panel).textContent = 'Noch kein Wurf';
  $('.zp-info', panel).textContent = zoneWahl ? 'Zone anklicken, um zu zielen' : 'Zahl = Rüstung der getroffenen Figur';
});

/* Würfelanzeige aus dem Kampftext ("Wurf 37 wird 73, Körper. …") */
on('blick', b => {
  if (b === last) return; last = b;
  const m = /Wurf (\d+)/.exec(b.text); if (!m) return;
  const wurf = +m[1], zm = /wird (\d+), ([^.]+)\./.exec(b.text), zone = zm ? REV[zm[2]] : null;
  const main = $('.d-main', panel), sub = $('.d-sub', panel);
  clearInterval(timer); main.classList.add('rolling'); let n = 0;
  timer = setInterval(() => {
    main.textContent = 1 + Math.floor(Math.random() * 100);
    if (++n < 10) return;
    clearInterval(timer); main.classList.remove('rolling'); main.textContent = wurf;
    let s = ART[b.art] || '';
    if (zm) s += ` · gedreht ${zm[1]} → ${zm[2]}`;
    if (b.art === 'patzer') { const p = W.patzerZeile(wurf); s += ` · ${p.name}: ${p.folge}`; }
    if (/Kritisch/.test(b.text)) s += ' · Kritisch';
    sub.textContent = s;
    const arm = W.charakter(b.ziel).ruestung;
    panel.querySelectorAll('g[data-z]').forEach(g => { g.classList.toggle('hit', g.dataset.z === zone); $('text', g).textContent = arm[g.dataset.z]; });
  }, 50);
});

/* Krit- und Patzertafeln */
function tafeln() {
  if ($('.tafeln-modal')) return $('.tafeln-modal').remove();
  const m = el('div', 'panel tafeln-modal', `<div class="zp-head"><b>Kritische Wunden und Patzer</b><button id="tmClose">Schließen</button></div><div class="tm-tabs"></div><div class="tm-body"></div>`);
  const show = k => {
    $('.tm-tabs', m).querySelectorAll('button').forEach(x => x.classList.toggle('on', x.dataset.k === k));
    const rows = k === 'patzer' ? W.PATZER.map(r => [r.von, r.bis, r.name, '', r.folge, false]) : W.KRIT[k].map(r => [r.von, r.bis, r.name, `${r.wunden} W`, r.folge, r.tot]);
    $('.tm-body', m).innerHTML = `<table>${rows.map(r => `<tr class="${r[5] ? 'tot' : ''}"><td>${r[0]}–${r[1]}</td><td><b></b>${r[3]}</td><td></td></tr>`).join('')}</table>`;
    $('.tm-body', m).querySelectorAll('tr').forEach((tr, i) => { $('b', tr).textContent = rows[i][2] + ' '; tr.lastChild.textContent = rows[i][4]; });
  };
  [...ZONES, 'patzer'].forEach(k => { const b = el('button', ''); b.textContent = k === 'patzer' ? 'Patzer' : ZN[k]; b.dataset.k = k; b.onclick = () => show(k); $('.tm-tabs', m).appendChild(b); });
  $('#tmClose', m) ; m.querySelector('#tmClose').onclick = () => m.remove();
  document.body.appendChild(m); show('kopf');
}
$('#tafelBtn', panel).onclick = tafeln;
addEventListener('keydown', e => { if (e.key === 't' || e.key === 'T') tafeln(); });
