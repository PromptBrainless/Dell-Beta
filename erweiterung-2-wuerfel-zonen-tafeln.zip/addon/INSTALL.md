# Erweiterung 2: Würfel, Trefferzonen, Tafeln
Neue Dateien: `css/zones.css`, `js/game/extras.js` (in dein Projekt kopieren). Dazu drei Änderungen:

1. `index.html`: nach `css/log-panel.css` einfügen: `<link rel="stylesheet" href="css/zones.css">`
   und vor der Zeile mit `js/game/bridge.js` einfügen: `<script type="module" src="js/game/extras.js"></script>`
2. `js/game/bridge.js`, in `apply()`: `if (S.blick) lastBlick = S.blick;` ersetzen durch
   `if (S.blick) { lastBlick = S.blick; emit('blick', S.blick); }`
3. `js/game/bridge.js`: in `setup()` nach `render();` ergänzen: `emit('fightStart', { zoneWahl: S.kaempfer.A.zoneWahl });`
   und bei den Aktionen `makro(s, 'schlag')` bzw. `makro(s, 'hinein')` jeweils `, window.hudZone || null` als dritten Parameter.

Das vollständige Projekt (vtt-hud.zip) enthält diese Änderungen schon.
